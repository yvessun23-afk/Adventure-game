/* ============================================================
   CharLib: geriggte 3D-Figuren (aus Mixamo/GLB, gepackt mit tools/pack_char.cjs)
   Haut-Animation auf der GPU, Toon/Painted-Material, Rückfall auf die prozeduralen Figuren, falls Daten fehlen.
   ============================================================ */
const CharLib = (() => {
  const chars = {};
  const VS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aUV; layout(location=3) in uvec4 aJ; layout(location=4) in vec4 aW;
uniform mat4 uVP; uniform mat4 uModel; uniform mat4 uJ[NJ];
out vec3 vW; out vec3 vN; out vec2 vUV; out float vLY;
void main(){
  vLY=aP.y;
  mat4 S=aW.x*uJ[aJ.x]+aW.y*uJ[aJ.y]+aW.z*uJ[aJ.z]+aW.w*uJ[aJ.w];
  vec4 w=uModel*(S*vec4(aP,1.));
  vW=w.xyz; vN=mat3(uModel)*(mat3(S)*aN); vUV=aUV;
  gl_Position=uVP*w;
}`;
  const VS_I = `#version 300 es
precision highp float;
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aUV;
layout(location=5) in vec4 iM0; layout(location=6) in vec4 iM1; layout(location=7) in vec4 iM2; layout(location=8) in vec4 iM3; layout(location=9) in vec4 iA; layout(location=10) in vec4 iB;
uniform mat4 uVP;
out vec3 vW; out vec3 vN; out vec2 vUV; out float vLY; flat out vec4 vA; flat out vec4 vB;
void main(){
  mat4 M=mat4(iM0,iM1,iM2,iM3); vec4 w=M*vec4(aP,1.);
  vLY=aP.y; vW=w.xyz; vN=mat3(M)*aN; vUV=aUV; vA=iA; vB=iB;
  gl_Position=uVP*w;
}`;
  const FS = `#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec2 vUV;
in float vLY;
#ifdef INST
flat in vec4 vA; flat in vec4 vB;   // je Instanz: (Hue, Emis, Sat, Fill) und (Mul rgb, Fade)
#define uHue vA.x
#define uEmis vA.y
#define uSat vA.z
#define uFill vA.w
#define uMul vB.rgb
#define uFade vB.a
#define uStyle 0
#define uTintC vec3(1.)
#define uClipY 1e9
uniform sampler2D uTex; uniform float uWin;
#else
uniform float uClipY;
uniform sampler2D uTex; uniform float uWin; uniform int uStyle; uniform vec3 uTintC; uniform float uFade; uniform vec3 uMul; uniform float uHue; uniform float uEmis; uniform float uSat; uniform float uFill;
#endif
${GLSL_COMMON}
${GLSL_LIGHTS}
out vec4 o;
void main(){
  if(uMirror==1 && vW.y<-0.02) discard;
  if(vLY>uClipY) discard;
  float nl=length(vN); vec3 gn=normalize(cross(dFdx(vW),dFdy(vW)));   // manche Meshy-Eckpunkte haben Normale 0 -> NaN -> schwarze Flächen; dort Flächennormale nehmen
  vec3 n=nl>.05? vN/nl : gn; if(!gl_FrontFacing) n=-n;
  vec3 Vv=uCam-vW; float dist=length(Vv); Vv/=dist;
  vec3 alb=texture(uTex,vUV).rgb;
  if(uHue!=0.){   // Kleidungsfarbe drehen, Hauttöne (orange-beige) bleiben
    float mx=max(alb.r,max(alb.g,alb.b)), mn=min(alb.r,min(alb.g,alb.b)), sat=(mx-mn)/max(mx,.001);
    float hue=degrees(atan(1.7320508*(alb.g-alb.b),2.*alb.r-alb.g-alb.b));
    float skin=smoothstep(2.,12.,hue)*(1.-smoothstep(34.,46.,hue))*smoothstep(.12,.25,sat)*(1.-smoothstep(.5,.65,sat))*smoothstep(.45,.6,mx);
    vec3 k=vec3(.57735), rot=alb*cos(uHue)+cross(k,alb)*sin(uHue)+k*dot(k,alb)*(1.-cos(uHue));
    alb=mix(rot,alb,skin);
  }
  alb*=uMul;
  float fr=pow(1.-max(dot(n,Vv),0.),3.);
  if(uStyle==1){            // Hologramm: Farbton + Scanlines + Fresnel, additiv wirkend
    float lum=dot(alb,vec3(.3,.59,.11));
    float scan=.65+.35*sin(vW.y*60.-uTime*6.);
    float fl=.85+.15*sin(uTime*23.)*step(.97,fract(uTime*.7));
    vec3 col=(uTintC*(.6+lum*1.2)+uTintC*fr*1.8)*scan*fl;
    col=applyFog(col,dist,vW.y);
    o=vec4(col*uFade,1.); return;
  }
  vec3 lit=uAmb*(.5+.5*(n.y*.5+.5))+vec3(.03,.035,.05);
  lit+=vec3(.5,.55,.8)*uFlash*(.25+.75*max(n.y,0.));
  lit+=(uAmb+vec3(.05,.055,.08))*.28*max(dot(n,Vv),0.);   // schwaches Fülllicht von der Kamera, damit Gesichter lesbar bleiben
  vec3 rim=vec3(0.);
  int LN=uEmis>0.?3:8;   // Gebäude brauchen nur die nächsten Lichter
  for(int i=0;i<LN;i++){ vec3 d=uLP[i].xyz-vW; float l=length(d); float a=1./(1.+l*l/(uLP[i].w*uLP[i].w));
    float ndl=max(dot(n,d/l),0.); ndl=smoothstep(.08,.55,ndl)*.85+ndl*.15; lit+=uLC[i]*ndl*a*.8; rim+=uLC[i]*a*fr; }
  float lum=dot(alb,vec3(.3,.59,.11));
  float bld=step(.001,uEmis);   // Gebäude: kein Neon-Randlicht, kein Zusatzglühen (sonst milchiger Schein)
  vec3 col=alb*lit+(1.-bld)*(rim*.14*(.4+alb*.6));   // Figuren: nur ein ganz schwaches Randlicht, kein Zusatzglühen mehr
  col/=1.+max(col.r,max(col.g,col.b))*.18;   // weicher Deckel gegen ausgebrannte Flächen unter hellen Laternen
  if(uEmis>0.){   // Gebäude: Fenster (helle, gesättigte Flächen) leuchten scharf; Fassade bleibt dunkel. uFill = schwaches Umgebungslicht (Dächer, Unterseiten)
    float mxE=max(alb.r,max(alb.g,alb.b));
    col+=alb*smoothstep(.5,.8,mxE)*uEmis*(.45+uWin);
    col+=uFill*(alb*vec3(.55,.5,.8)*.2*uEmis*(.3+.7*max(n.y,0.))+alb*vec3(1.1,.62,.5)*.6*uEmis*max(-n.y,0.)+alb*vec3(.5,.45,.7)*.1*uEmis+vec3(.02,.02,.035)*uEmis);
  }
  col=mix(vec3(dot(col,vec3(.3,.59,.11))),col,uSat);   // Sättigung (1 = unverändert)
  col=applyFog(col,dist,vW.y);
  o=vec4(col*uFade,1.);
}`;
  let prog_ = null, progI_ = null;

  function b64(s) { const r = atob(s), u = new Uint8Array(r.length); for (let i = 0; i < r.length; i++) u[i] = r.charCodeAt(i); return u; }
  function init() {
    for (const name in (window.CHAR_DATA || {})) { if (!chars[name]) try { load(name); } catch (e) { console.warn('CharLib', name, e); } }
  }
  function load(name) {
    const d = CHAR_DATA[name], h = d.h, u = b64(d.b), buf = u.buffer;
    const T = { P: Float32Array, N: Float32Array, UV: Float32Array, JI: Uint8Array, W: Uint8Array, IDX: Uint16Array, IBM: Float32Array, parent: Int32Array, restT: Float32Array, restR: Float32Array, restS: Float32Array, joints: Int32Array };
    const get = (k, Ty) => { const [o, n] = h.buf[k]; return new (Ty || T[k])(buf, o, n); };
    if (!prog_) { prog_ = prog(VS.replace(/NJ/g, h.nj), FS); progI_ = prog(VS_I, FS.replace('#version 300 es', '#version 300 es\n#define INST 1')); }
    const c = { h, nj: h.nj, nn: h.nodes, parent: get('parent'), restT: get('restT'), restR: get('restR'), restS: get('restS'), joints: get('joints'), ibm: get('IBM'), clips: {}, ready: false };
    c.vao = gl.createVertexArray(); gl.bindVertexArray(c.vao);
    const bufs = {}; const mk = (loc, arr, size, type, norm, integer) => { const b = gl.createBuffer(); bufs[loc] = b; gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW); gl.enableVertexAttribArray(loc); if (integer) gl.vertexAttribIPointer(loc, size, type, 0, 0); else gl.vertexAttribPointer(loc, size, type, norm, 0, 0); };
    mk(0, get('P'), 3, gl.FLOAT); mk(1, get('N'), 3, gl.FLOAT); mk(2, get('UV'), 2, gl.FLOAT); mk(3, get('JI'), 4, gl.UNSIGNED_BYTE, false, true); mk(4, get('W'), 4, gl.UNSIGNED_BYTE, true);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, get('IDX'), gl.STATIC_DRAW);
    gl.bindVertexArray(null); c.ni = h.ni;
    // Instanz-VAO (starre Modelle: Gebäude, Taxis, ... in einem Aufruf): Position/Normale/UV wie oben + je Instanz Matrix und Parameter
    c.vaoI = gl.createVertexArray(); gl.bindVertexArray(c.vaoI);
    [[0, 3], [1, 3], [2, 2]].forEach(([loc, sz]) => { gl.bindBuffer(gl.ARRAY_BUFFER, bufs[loc]); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, sz, gl.FLOAT, false, 0, 0); });
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    c.ibuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, c.ibuf); c.idata = new Float32Array(24 * 64);
    for (let k = 0; k < 6; k++) { gl.enableVertexAttribArray(5 + k); gl.vertexAttribPointer(5 + k, 4, gl.FLOAT, false, 96, k * 16); gl.vertexAttribDivisor(5 + k, 1); }
    gl.bindVertexArray(null);
    for (const cn in h.clips) c.clips[cn] = Object.assign({ rn: get('c_' + cn + '_rn', Int32Array), tn: get('c_' + cn + '_tn', Int32Array), rot: get('c_' + cn + '_rot', Float32Array), tr: get('c_' + cn + '_tr', Float32Array) }, h.clips[cn]);
    c.lt = new Float32Array(c.nn * 3); c.lr = new Float32Array(c.nn * 4); c.world = new Float32Array(c.nn * 16); c.skin = new Float32Array(c.nj * 16); c.tmp = new Float32Array(16);
    c.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, c.tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([128, 128, 128, 255]));
    const img = new Image(); img.onload = () => {
      gl.bindTexture(gl.TEXTURE_2D, c.tex); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img); gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      const an = gl.getExtension('EXT_texture_filter_anisotropic'); if (an) gl.texParameterf(gl.TEXTURE_2D, an.TEXTURE_MAX_ANISOTROPY_EXT, 4);
      c.ready = true;
    };
    const [jo, jn] = h.buf.jpg; img.src = 'data:image/jpeg;base64,' + btoa(Array.from(new Uint8Array(buf, jo, jn), x => String.fromCharCode(x)).join(''));
    chars[name] = c;
  }
  const ready = (name) => !!(chars[name] && chars[name].ready);

  /* ---- 4x4 Hilfen (spaltenweise) ---- */
  function qm(o, oo, q, qo, t, to, s, so) {
    const x = q[qo], y = q[qo + 1], z = q[qo + 2], w = q[qo + 3], sx = s[so], sy = s[so + 1], sz = s[so + 2];
    o[oo] = (1 - 2 * (y * y + z * z)) * sx; o[oo + 1] = 2 * (x * y + z * w) * sx; o[oo + 2] = 2 * (x * z - y * w) * sx; o[oo + 3] = 0;
    o[oo + 4] = 2 * (x * y - z * w) * sy; o[oo + 5] = (1 - 2 * (x * x + z * z)) * sy; o[oo + 6] = 2 * (y * z + x * w) * sy; o[oo + 7] = 0;
    o[oo + 8] = 2 * (x * z + y * w) * sz; o[oo + 9] = 2 * (y * z - x * w) * sz; o[oo + 10] = (1 - 2 * (x * x + y * y)) * sz; o[oo + 11] = 0;
    o[oo + 12] = t[to]; o[oo + 13] = t[to + 1]; o[oo + 14] = t[to + 2]; o[oo + 15] = 1;
  }
  function mmul(o, oo, a, ao, b, bo) {
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[ao + k * 4 + r] * b[bo + c * 4 + k]; o[oo + c * 4 + r] = s; }
  }
  /* Pose berechnen: schreibt c.skin (Gelenkmatrizen) */
  function pose(c, clipName, t, loop) {
    const cl = c.clips[clipName] || c.clips.idle || Object.values(c.clips)[0];
    c.lt.set(c.restT); c.lr.set(c.restR);
    let f = Math.max(0, t) * 30; const nf = cl.n;
    if (loop) f = f % (nf - 1); else f = Math.min(f, nf - 1);
    const i0 = Math.floor(f), i1 = Math.min(i0 + 1, nf - 1), fr = f - i0;
    const nr = cl.rn.length, nt = cl.tn.length, lr = c.lr, lt = c.lt;
    for (let k = 0; k < nr; k++) {
      const a = (i0 * nr + k) * 4, b = (i1 * nr + k) * 4, o = cl.rn[k] * 4; let d = 0;
      for (let m = 0; m < 4; m++) d += cl.rot[a + m] * cl.rot[b + m]; const sg = d < 0 ? -fr : fr; let l = 0;
      for (let m = 0; m < 4; m++) { const v = cl.rot[a + m] * (1 - fr) + cl.rot[b + m] * sg; lr[o + m] = v; l += v * v; }
      l = 1 / (Math.sqrt(l) || 1); for (let m = 0; m < 4; m++) lr[o + m] *= l;
    }
    for (let k = 0; k < nt; k++) { const a = (i0 * nt + k) * 3, b = (i1 * nt + k) * 3, o = cl.tn[k] * 3; for (let m = 0; m < 3; m++) lt[o + m] = cl.tr[a + m] * (1 - fr) + cl.tr[b + m] * fr; }
    const W = c.world, tmp = c.tmp;
    for (let i = 0; i < c.nn; i++) {
      const p = c.parent[i];
      if (p < 0) qm(W, i * 16, lr, i * 4, lt, i * 3, c.restS, i * 3);
      else { qm(tmp, 0, lr, i * 4, lt, i * 3, c.restS, i * 3); mmul(W, i * 16, W, p * 16, tmp, 0); }
    }
    for (let j = 0; j < c.nj; j++) mmul(c.skin, j * 16, W, c.joints[j] * 16, c.ibm, j * 16);
    return cl;
  }

  /* Alle Figuren eines Layers zeichnen (im Opaque-Durchgang, auch für die Spiegelung).
     Starre Modelle ohne Sonderfälle (Gebäude, Taxis, Automaten ...) werden pro Modell in EINEM Instanz-Aufruf gezeichnet, die übrigen einzeln (Skelett). */
  const model = new Float32Array(16);
  function drawAll(layers, vp, env, cam, T, mirror) {
    let any = false; for (const L of layers) if (L.figs.length) any = true;
    if (!any || !prog_) return;
    const cp = cam.p, inst = {}, rest = [];
    for (const L of layers) for (const f of L.figs) {
      const c = chars[f.name]; if (!c || !c.ready) continue;
      if (mirror && f.mm !== undefined) { const dx = f.x - cp[0], dz = f.z - cp[2], dy = f.y - cp[1]; if (dx * dx + dz * dz + dy * dy > f.mm * f.mm) continue; }   // in der Spiegelung nur Nahes
      if (c.nj === 1 && !f.style && !f.roll && f.clipY === undefined) (inst[f.name] = inst[f.name] || []).push(f); else rest.push(f);
    }
    gl.disable(gl.BLEND); gl.depthMask(true); gl.enable(gl.DEPTH_TEST); gl.activeTexture(gl.TEXTURE2);
    // 1) Instanzen
    const names = Object.keys(inst);
    if (names.length) {
      const p = progI_; gl.useProgram(p); setCommon(p, env, cam, T, mirror); setLights(p, env);
      gl.uniformMatrix4fv(U(p, 'uVP'), false, vp); u1f(p, 'uWin', env.win); u1i(p, 'uTex', 2);
      for (const name of names) {
        const c = chars[name], list = inst[name], n = list.length;
        if (c.idata.length < n * 24) c.idata = new Float32Array(n * 24 * 2);
        const D = c.idata, y0 = c.clips.idle.y0 || 0, s0 = 1 / c.h.H;
        for (let i = 0; i < n; i++) {
          const f = list[i], cy = Math.cos(f.yaw), sy = Math.sin(f.yaw), o = i * 24;
          let ax, ay, az; if (f.scl) { ax = f.scl[0]; ay = f.scl[1]; az = f.scl[2]; } else { ax = ay = az = f.h * s0; }
          const yb = f.y - (f.refY0 ? y0 : (c.clips.idle.y0 || 0)) * ay, m = f.mul || [1, 1, 1];
          D[o] = cy * ax; D[o + 1] = 0; D[o + 2] = -sy * ax; D[o + 3] = 0; D[o + 4] = 0; D[o + 5] = ay; D[o + 6] = 0; D[o + 7] = 0; D[o + 8] = sy * az; D[o + 9] = 0; D[o + 10] = cy * az; D[o + 11] = 0; D[o + 12] = f.x; D[o + 13] = yb; D[o + 14] = f.z; D[o + 15] = 1;
          D[o + 16] = f.hue || 0; D[o + 17] = f.emis || 0; D[o + 18] = f.sat === undefined ? 1 : f.sat; D[o + 19] = f.fill === undefined ? 1 : f.fill;
          D[o + 20] = m[0]; D[o + 21] = m[1]; D[o + 22] = m[2]; D[o + 23] = f.fade === undefined ? 1 : f.fade;
        }
        gl.bindVertexArray(c.vaoI); gl.bindBuffer(gl.ARRAY_BUFFER, c.ibuf); gl.bufferData(gl.ARRAY_BUFFER, D.subarray(0, n * 24), gl.DYNAMIC_DRAW);
        gl.bindTexture(gl.TEXTURE_2D, c.tex); gl.drawElementsInstanced(gl.TRIANGLES, c.ni, gl.UNSIGNED_SHORT, 0, n);
      }
    }
    // 2) Einzelfiguren (Skelett, Rotation, abgeschnittene Teile, Hologramme)
    if (rest.length) {
      rest.sort((x, y) => x.style - y.style);   // erst deckende Figuren, dann additive Hologramme
      const p = prog_; gl.useProgram(p); setCommon(p, env, cam, T, mirror); setLights(p, env);
      gl.uniformMatrix4fv(U(p, 'uVP'), false, vp); u1f(p, 'uWin', env.win); u1i(p, 'uTex', 2);
      let holo = false;
      for (const f of rest) {
        const c = chars[f.name];
        if (f.style === 1 && !holo) { holo = true; gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); gl.depthMask(false); gl.enable(gl.CULL_FACE); gl.cullFace(mirror ? gl.FRONT : gl.BACK); }
        const cl = pose(c, f.clip, f.t, f.loop);
        const s = f.h / c.h.H, cy = Math.cos(f.yaw), sy = Math.sin(f.yaw);
        const cr = Math.cos(f.roll), sr = Math.sin(f.roll), ty = f.y - ((f.refY0 ? c.clips.idle.y0 : cl.y0) || 0) * s;
        if (f.scl) { const [ax, ay, az] = f.scl; model.set([cy * ax, 0, -sy * ax, 0, 0, ay, 0, 0, sy * az, 0, cy * az, 0, f.x, f.y - ((f.refY0 ? c.clips.idle.y0 : cl.y0) || 0) * ay, f.z, 1]); }
        else if (!f.roll) model.set([cy * s, 0, -sy * s, 0, 0, s, 0, 0, sy * s, 0, cy * s, 0, f.x, ty, f.z, 1]);
        else if (!f.rollX) model.set([cr * cy * s, sr * s, -cr * sy * s, 0, -sr * cy * s, cr * s, sr * sy * s, 0, sy * s, 0, cy * s, 0, f.x, ty, f.z, 1]);   // Neigung um die Vorwärtsachse (z)
        else model.set([cy * s, 0, -sy * s, 0, sr * sy * s, cr * s, sr * cy * s, 0, cr * sy * s, -sr * s, cr * cy * s, 0, f.x, ty, f.z, 1]);   // dito für das Brett (Vorwärtsachse x)
        gl.uniformMatrix4fv(U(p, 'uModel'), false, model); gl.uniformMatrix4fv(U(p, 'uJ'), false, c.skin);
        u1f(p, 'uClipY', f.clipY === undefined ? 1e9 : f.clipY); u1i(p, 'uStyle', f.style); u3(p, 'uTintC', f.tint || [.3, .9, 1]); u1f(p, 'uFade', f.fade === undefined ? 1 : f.fade); u3(p, 'uMul', f.mul || [1, 1, 1]); u1f(p, 'uHue', f.hue || 0); u1f(p, 'uEmis', f.emis || 0); u1f(p, 'uSat', f.sat === undefined ? 1 : f.sat); u1f(p, 'uFill', f.fill === undefined ? 1 : f.fill);
        gl.bindTexture(gl.TEXTURE_2D, c.tex); gl.bindVertexArray(c.vao); gl.drawElements(gl.TRIANGLES, c.ni, gl.UNSIGNED_SHORT, 0);
      }
      if (holo) { gl.disable(gl.BLEND); gl.disable(gl.CULL_FACE); gl.depthMask(true); }
    }
    gl.bindVertexArray(null); gl.activeTexture(gl.TEXTURE0);
  }
  const hasClip = (name, cn) => !!(chars[name] && chars[name].clips[cn]);
  const info = (name) => { const k = chars[name]; if (!k) return null; const b = k.h.bbox; return { H: k.h.H, y0: k.clips.idle.y0, W: b.mx[0] - b.mn[0], D: b.mx[2] - b.mn[2] }; };
  return { init, ready, drawAll, chars, info, hasClip };
})();
