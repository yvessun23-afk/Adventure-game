#!/usr/bin/env node
// Packt eine Mixamo-Figur (GLB aus FBX2glTF) + Animations-GLBs in eine kompakte JS-Datei (Base64) für die Neon-Noodle-Engine.
// Aufruf: node tools/pack_char.cjs <name> <basis.glb> <textur_groesse> clip=datei.glb ... > out
const fs = require('fs'), cp = require('child_process'), os = require('os'), path = require('path');
const [name, baseFile, texSize, ...clipArgs] = process.argv.slice(2);
function loadGLB(p) {
  const b = fs.readFileSync(p); const jl = b.readUInt32LE(12); const j = JSON.parse(b.slice(20, 20 + jl).toString());
  const off = 20 + jl + 8; return { j, bin: b.slice(off) };
}
const CT = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array }, NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
function acc(g, i) {
  const a = g.j.accessors[i], bv = g.j.bufferViews[a.bufferView], T = CT[a.componentType], n = NC[a.type], out = new T(a.count * n);
  const base = (bv.byteOffset || 0) + (a.byteOffset || 0), stride = bv.byteStride || n * T.BYTES_PER_ELEMENT;
  const dv = new DataView(g.bin.buffer, g.bin.byteOffset + base - 0, 0); // unused, copy per element
  for (let k = 0; k < a.count; k++) for (let c = 0; c < n; c++) {
    const o = g.bin.byteOffset + base + k * stride + c * T.BYTES_PER_ELEMENT;
    const d = new DataView(g.bin.buffer, o, T.BYTES_PER_ELEMENT);
    out[k * n + c] = T === Float32Array ? d.getFloat32(0, true) : T === Uint16Array ? d.getUint16(0, true) : T === Uint32Array ? d.getUint32(0, true) : T === Uint8Array ? d.getUint8(0) : T === Int16Array ? d.getInt16(0, true) : d.getInt8(0);
  }
  return out;
}
const base = loadGLB(baseFile), J = base.j, isStatic = !J.skins;   // statisch: Modell ohne Skelett (z. B. Krümel) -> 1 Dummy-Gelenk
const nodes = isStatic ? [{ name: 'root' }] : J.nodes, parent = new Int32Array(nodes.length).fill(-1);
if (!isStatic) nodes.forEach((n, i) => (n.children || []).forEach(c => parent[c] = i));
const meshNodeIdx = J.nodes.findIndex(n => n.mesh !== undefined), skin = isStatic ? { joints: [0] } : J.skins[0];
const prim = J.meshes[J.nodes[meshNodeIdx].mesh].primitives[0];
const P = acc(base, prim.attributes.POSITION), N = acc(base, prim.attributes.NORMAL), UV = acc(base, prim.attributes.TEXCOORD_0);
const IDX = acc(base, prim.indices);
let JI, W, IBM;
if (isStatic) {
  const m = J.nodes[meshNodeIdx].matrix || [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];   // Knotentransformation einbacken
  for (let i = 0; i < P.length; i += 3) { const x = P[i], y = P[i + 1], z = P[i + 2]; for (let c = 0; c < 3; c++) P[i + c] = m[c] * x + m[4 + c] * y + m[8 + c] * z + m[12 + c]; }
  const nv0 = P.length / 3; JI = new Uint8Array(nv0 * 4); W = new Float32Array(nv0 * 4); for (let v = 0; v < nv0; v++) W[v * 4] = 1;
  IBM = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
} else { JI = acc(base, prim.attributes.JOINTS_0); W = acc(base, prim.attributes.WEIGHTS_0); IBM = acc(base, skin.inverseBindMatrices); }
const nv = P.length / 3;
// rest transforms
const restT = new Float32Array(nodes.length * 3), restR = new Float32Array(nodes.length * 4), restS = new Float32Array(nodes.length * 3);
nodes.forEach((n, i) => { restT.set(n.translation || [0, 0, 0], i * 3); restR.set(n.rotation || [0, 0, 0, 1], i * 4); restS.set(n.scale || [1, 1, 1], i * 3); });
// order check: parent before child
for (let i = 0; i < nodes.length; i++) if (parent[i] > i) throw new Error('Knotenreihenfolge: Eltern müssen vor Kindern stehen');
// weights -> uint8 (summe 255)
const W8 = new Uint8Array(nv * 4), JI8 = new Uint8Array(nv * 4);
for (let v = 0; v < nv; v++) {
  let s = 0; for (let k = 0; k < 4; k++) s += W[v * 4 + k]; s = s || 1; let t = 0, mx = 0;
  for (let k = 0; k < 4; k++) { W8[v * 4 + k] = Math.round(W[v * 4 + k] / s * 255); t += W8[v * 4 + k]; if (W[v * 4 + k] > W[v * 4 + mx]) mx = k; JI8[v * 4 + k] = JI[v * 4 + k]; }
  W8[v * 4 + mx] += 255 - t;
}
// texture -> jpeg
const mat = J.materials && J.materials[prim.material !== undefined ? prim.material : 0], texIdx = mat && mat.pbrMetallicRoughness && mat.pbrMetallicRoughness.baseColorTexture ? mat.pbrMetallicRoughness.baseColorTexture.index : 0;
const img = J.images[J.textures ? J.textures[texIdx].source : 0], bvI = J.bufferViews[img.bufferView];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-')), png = path.join(tmp, 't.png'), jpg = path.join(tmp, 't.jpg');
fs.writeFileSync(png, base.bin.slice(bvI.byteOffset || 0, (bvI.byteOffset || 0) + bvI.byteLength));
cp.execFileSync('python3', ['-c', `from PIL import Image;im=Image.open(${JSON.stringify(png)}).convert('RGB');im=im.resize((${texSize},${texSize}),Image.LANCZOS);im.save(${JSON.stringify(jpg)},quality=88)`]);
const JPG = fs.readFileSync(jpg);
// clips
const nameToNode = {}; nodes.forEach((n, i) => nameToNode[n.name] = i);
const hips = nodes.findIndex(n => /Hips$/.test(n.name));
function qn(a, o) { const l = Math.hypot(a[o], a[o + 1], a[o + 2], a[o + 3]) || 1; for (let k = 0; k < 4; k++) a[o + k] /= l; }
function sampleLin(times, vals, n, t, out, isQ) {
  let i = 0; while (i < times.length - 2 && times[i + 1] <= t) i++;
  const t0 = times[i], t1 = times[Math.min(i + 1, times.length - 1)], f = t1 > t0 ? Math.min(1, Math.max(0, (t - t0) / (t1 - t0))) : 0, a = i * n, b = Math.min(i + 1, times.length - 1) * n;
  if (isQ) { let d = 0; for (let k = 0; k < 4; k++) d += vals[a + k] * vals[b + k]; const s = d < 0 ? -1 : 1; for (let k = 0; k < 4; k++) out[k] = vals[a + k] * (1 - f) + vals[b + k] * s * f; qn(out, 0); }
  else for (let k = 0; k < n; k++) out[k] = vals[a + k] * (1 - f) + vals[b + k] * f;
}
const clips = {}, FPS = 30;
if (isStatic) clips.idle = { dur: 1, n: 2, rn: [], tn: [], rot: new Float32Array(0), tr: new Float32Array(0) };
for (const ca of (isStatic ? [] : clipArgs)) {
  const [cn, file] = ca.split('='), g = loadGLB(file), an = g.j.animations[0], map = {};
  for (const ch of an.channels) { const nn = nodes.findIndex(n => n.name === g.j.nodes[ch.target.node].name); (map[nn] = map[nn] || {})[ch.target.path] = an.samplers[ch.sampler]; }
  let dur = 0; for (const nn in map) for (const p in map[nn]) { const t = acc(g, map[nn][p].input); dur = Math.max(dur, t[t.length - 1]); }
  const nf = Math.max(2, Math.round(dur * FPS) + 1), rn = Object.keys(map).filter(k => map[k].rotation).map(Number), tn = Object.keys(map).filter(k => map[k].translation).map(Number);
  const rot = new Float32Array(nf * rn.length * 4), tr = new Float32Array(nf * tn.length * 3), tmpv = new Float32Array(4);
  rn.forEach((nn, k) => { const s = map[nn].rotation, ti = acc(g, s.input), vv = acc(g, s.output); for (let f = 0; f < nf; f++) { sampleLin(ti, vv, 4, f / FPS, tmpv, true); rot.set(tmpv, (f * rn.length + k) * 4); } });
  tn.forEach((nn, k) => { const s = map[nn].translation, ti = acc(g, s.input), vv = acc(g, s.output); for (let f = 0; f < nf; f++) { sampleLin(ti, vv, 3, f / FPS, tmpv, false); tr.set(tmpv.subarray(0, 3), (f * tn.length + k) * 3); } });
  tn.forEach((nn, k) => { if (nn === hips) { const x0 = tr[k * 3], z0 = tr[k * 3 + 2]; for (let f = 0; f < nf; f++) { tr[(f * tn.length + k) * 3] = x0; tr[(f * tn.length + k) * 3 + 2] = z0; } } });   // in place
  clips[cn] = { dur: (nf - 1) / FPS, n: nf, rn, tn, rot, tr };
  console.error('clip', cn, 'frames', nf, 'rot', rn.length, 'trans', tn.length);
}
// --- bind pose bbox (control) ---
function qm(q, t, s) { const [x, y, z, w] = q; return [(1 - 2 * (y * y + z * z)) * s[0], 2 * (x * y + z * w) * s[0], 2 * (x * z - y * w) * s[0], 0, 2 * (x * y - z * w) * s[1], (1 - 2 * (x * x + z * z)) * s[1], 2 * (y * z + x * w) * s[1], 0, 2 * (x * z + y * w) * s[2], 2 * (y * z - x * w) * s[2], (1 - 2 * (x * x + y * y)) * s[2], 0, t[0], t[1], t[2], 1]; }
function mm(a, b) { const o = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k]; return o; }
function skinned(clip, f) {   // gibt min/max der Haut für ein Frame zurück (clip=null: Ruhepose)
  const lt = Float32Array.from(restT), lr = Float32Array.from(restR);
  if (clip) { clip.rn.forEach((nn, k) => lr.set(clip.rot.subarray((f * clip.rn.length + k) * 4, (f * clip.rn.length + k) * 4 + 4), nn * 4)); clip.tn.forEach((nn, k) => lt.set(clip.tr.subarray((f * clip.tn.length + k) * 3, (f * clip.tn.length + k) * 3 + 3), nn * 3)); }
  const world = []; nodes.forEach((n, i) => { const l = qm(lr.subarray(i * 4, i * 4 + 4), lt.subarray(i * 3, i * 3 + 3), restS.subarray(i * 3, i * 3 + 3)); world[i] = parent[i] >= 0 ? mm(world[parent[i]], l) : l; });
  const sk = skin.joints.map((nn, j) => mm(world[nn], Array.from(IBM.subarray(j * 16, j * 16 + 16))));
  const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  for (let v = 0; v < nv; v += 1) { const r = [0, 0, 0]; for (let k = 0; k < 4; k++) { const w = W8[v * 4 + k] / 255; if (!w) continue; const m = sk[JI8[v * 4 + k]], x = P[v * 3], y = P[v * 3 + 1], z = P[v * 3 + 2]; for (let c = 0; c < 3; c++) r[c] += w * (m[c] * x + m[4 + c] * y + m[8 + c] * z + m[12 + c]); } for (let c = 0; c < 3; c++) { mn[c] = Math.min(mn[c], r[c]); mx[c] = Math.max(mx[c], r[c]); } }
  return { mn, mx };
}
const rb = skinned(null, 0); console.error('ruhepose min', rb.mn.map(v => +v.toFixed(5)), 'max', rb.mx.map(v => +v.toFixed(5)));
for (const cn in clips) { const b = skinned(clips[cn], 0); clips[cn].y0 = b.mn[1]; clips[cn].h = b.mx[1] - b.mn[1]; console.error(cn, 'frame0 miny', b.mn[1].toFixed(5), 'höhe', clips[cn].h.toFixed(5)); }
const mn = rb.mn, mx = rb.mx;
// --- pack ---
const parts = [], hdr = { name, H: (clips.idle || { h: rb.mx[1] - rb.mn[1] }).h, nv, ni: IDX.length, nodes: nodes.length, nj: skin.joints.length, bbox: { mn, mx }, buf: {} };
let off = 0; const add = (k, ta) => { const u = new Uint8Array(ta.buffer, ta.byteOffset, ta.byteLength); off = (off + 3) & ~3; parts.push([off, u]); hdr.buf[k] = [off, ta.length]; off += u.length; };
add('P', P); add('N', N); add('UV', UV); add('JI', JI8); add('W', W8); add('IDX', IDX.length && nv < 65536 ? Uint16Array.from(IDX) : IDX); add('IBM', IBM);
add('parent', parent); add('restT', restT); add('restR', restR); add('restS', restS); add('joints', Int32Array.from(skin.joints));
hdr.names = nodes.map(n => n.name); hdr.clips = {};
for (const cn in clips) { const c = clips[cn]; add('c_' + cn + '_rn', Int32Array.from(c.rn)); add('c_' + cn + '_tn', Int32Array.from(c.tn)); add('c_' + cn + '_rot', c.rot); add('c_' + cn + '_tr', c.tr); hdr.clips[cn] = { dur: c.dur, n: c.n, y0: c.y0, h: c.h }; }
add('jpg', new Uint8Array(JPG));
const bin = Buffer.alloc((off + 3) & ~3); parts.forEach(([o, u]) => bin.set(u, o));
console.log(`/* generiert von tools/pack_char.cjs – nicht von Hand ändern */\nwindow.CHAR_DATA=window.CHAR_DATA||{};CHAR_DATA[${JSON.stringify(name)}]={h:${JSON.stringify(hdr)},b:"${bin.toString('base64')}"};`);
console.error('binär', (bin.length / 1024) | 0, 'KB (jpg', (JPG.length / 1024) | 0, 'KB)');
