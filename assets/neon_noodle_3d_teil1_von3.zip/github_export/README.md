# Neon Noodle: vorhandene 3D-Modelle (Upload-Paket)

Dieses Verzeichnis enthält **nur Modelle, die tatsächlich existieren** (164 Stück). Geplante, noch nicht erzeugte Objekte (z. B. aus `OBJEKTLISTE_3D.md`) und die Platzhalter-Würfel sind **nicht** enthalten.

| Pfad | Inhalt |
|---|---|
| `models/` | 164 gepackte Modelle `char_<id>.js` (zusammen ca. 80 MB, jede Datei unter 2 MB) |
| `loader/chars.js` | Lader und Zeichenroutine (`CharLib`, Skelett-Animation auf der GPU) |
| `loader/pack_char.cjs` | Werkzeug, mit dem GLB (+ Mixamo-Clips) zu `char_<id>.js` gepackt wird |
| `3D_UEBERSICHT.md` | Übersicht mit Eigenschaften je Modell |
| `assets_manifest.json` / `.csv` | dieselben Daten maschinenlesbar |

## Benutzung
```html
<script>window.CHAR_DATA = window.CHAR_DATA || {};</script>
<script src="models/char_npc_bello.js"></script>   <!-- je gewünschtes Modell -->
<script src="loader/chars.js"></script>
```
Zeichnen: `D.fig('npc_bello', x, y, z, yaw, höhe_in_m, 'idle', zeit, {})`. Animierte Modelle (Pixel, Kleo, Oma, Teddy, Bit, Baron, Hugo, Jackpot, Kabel, Rosi, Schnipp, Bürger, Roboter) haben Clips wie `walk`, `talk`, `idle`, `cheer`, `sad`.

## Rohmodelle (nicht enthalten, zu groß)
Die GLB-Rohdateien (ca. 0,87 GB) liegen in `neon_noodle_spiel/automation/modelle/`. Bei Bedarf separat per Git LFS hochladen.
