# 3D-Objekte von Neon Noodle: Übersicht für das GitHub-Repository

Stand: 164 Modelle. Alle Daten stammen aus den gepackten Modelldateien (`char_*.js`) und den Meshy-Rohmodellen (`.glb`).

## Auf einen Blick

| Kategorie | Anzahl |
|---|---|
| Held | 5 |
| NPC | 31 |
| Statist | 4 |
| Fahrzeug | 7 |
| Gebäude | 12 |
| Objekt | 1 |
| Prop | 55 |
| Gegenstand | 49 |
| **Gesamt** | **164** |

Dreiecke gesamt: 973.713. Davon animiert (mit Skelett): 15 Modelle. Gepackte Dateien (Base64 in JS): 79 MB. Rohmodelle (GLB): 0.87 GB.

## So hängt alles zusammen

- **Quelle:** Bild (Poe/Nano-Banana) → 3D-Modell (Meshy) → GLB in `neon_noodle_spiel/automation/modelle/<id>/`. Helden und Figuren aus dem Film sind zusätzlich über Mixamo geriggt und animiert.
- **Packen:** `tools/pack_char.cjs` (Film-Ordner `neon_noodle/`) wandelt GLB (+ Mixamo-Clips) in eine JS-Datei `char_<id>.js` mit Base64-Puffern (Positionen, Normalen, UV, Indizes, Gelenke, Textur 256 oder 512 px, Clips). Das Spiel nutzt `neon_noodle_spiel/src/models/`, der Film `neon_noodle/`.
- **Laden:** `CharLib.ready(name)` und `D.fig(name, x, y, z, yaw, höhe, clip, zeit, optionen)` (Engine `neon_noodle/engine.js` + `chars.js`).
- **Skelett:** Starre Modelle haben 1 Dummy-Gelenk und nur den Clip `idle` (1 s). Animierte Modelle haben 50+ Gelenke und Clips wie `idle`, `walk`, `talk`, `cheer`, `sad`.
- **Texturen:** Jedes Meshy-Modell hat im GLB drei Texturen (Farbe, Normal, Material) mit 2048 × 2048 px. Beim Packen wird nur die Farbtextur auf 256 px (Film-Props, Gegenstände, NPCs) oder 512 px (animierte Figuren) verkleinert.
- **Abmessung:** `abmessung_rel` ist die Boxgröße im Modellraum (Breite × Höhe × Tiefe), nicht in Metern. Die Größe in der Welt kommt aus dem Parameter „Höhe“ beim Zeichnen (z. B. Pixel 2,3 m, Oma 1,65 m).

## Hinweis für GitHub

- Die Rohmodelle (GLB) sind zusammen etwa 0,85 GB groß und passen nicht in ein normales Repository (100 MB pro Datei). Entweder **Git LFS** verwenden oder nur die gepackten `char_*.js` (rund 58 MB für das Spiel) hochladen.
- Die Modelle wurden mit KI-Werkzeugen erzeugt (Poe/Nano-Banana für Bilder, Meshy für 3D, Mixamo für Skelett und Animationen). Bitte vor der Veröffentlichung die Nutzungsbedingungen der Dienste für Weitergabe und kommerzielle Nutzung prüfen.
- Für die 2D-Version reichen die Vorschaubilder in `automation/ausgabe/helden/*.png` (Figuren) und `automation/ausgabe/items/` (Gegenstände).

### Held (5)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Kleo | kleo | Hologramm / Geist | 15594 | 34 | idle (16.63 s), talk (5.9 s), fly (2.63 s), walk (0.97 s), float (3.57 s), float2 (3 s) | — | — | 1663 | True |
| Krümel | kruemel | Toaster mit Flügeln | 15386 | 0 | — | — | — | 983 | True |
| Oma Zhang | oma | Imbiss-Besitzerin | 15758 | 46 | idle (7.33 s), talk (5.9 s), sad (2.8 s), walk (1.67 s), cook (9.7 s) | — | — | 1816 | True |
| Pixel | pixel | Heldin, Kurierin vom Køpi-Korps | 15726 | 52 | idle (1.97 s), walk (1 s), talk (3.77 s), glide (1 s), push (2.17 s) | — | — | 1530 | True |
| Teddy-Bot | teddy | Roboter-Teddy | 15558 | 46 | idle (6 s), sad (2.8 s), talk (3.93 s), walk (1.37 s) | — | — | 1384 | True |

### NPC (31)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Baron von Chrom | npc_baron | Villa | 8376 | 46 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 7.7 | 980 | True |
| Bello-5000 | npc_bello | Wachroboter, Nudelgasse | 8388 | 0 | — | 3× 2048×2048 | 7.4 | 529 | True |
| Bit | npc_bit | Barkeeper-Roboter, Bar | 8244 | 46 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 7.7 | 956 | True |
| Brezel | npc_brezel | Bäcker, Bäckerei | 8374 | 0 | — | 3× 2048×2048 | 6.7 | 523 | True |
| Chef Kloß | npc_kloss | Küchenchef, Kantine | 8254 | 0 | — | 3× 2048×2048 | 6.1 | 539 | True |
| Dr. Schraub | npc_schraub | Wissenschaftler | 8415 | 0 | — | 3× 2048×2048 | 6.5 | 529 | True |
| Flughans | npc_flughans | Pilot | 8058 | 0 | — | 3× 2048×2048 | 6.4 | 510 | True |
| Frau Ablage | npc_ablage | Aktenschrank-Beamtin, Lobby | 7958 | 0 | — | 3× 2048×2048 | 6.4 | 518 | True |
| Grünhorn | npc_gruenhorn | Gärtner-Roboter | 7593 | 0 | — | 3× 2048×2048 | 7.8 | 517 | True |
| Hehler-Hugo | npc_hugo | Hehler, Basar | 8358 | 52 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 6.9 | 1009 | True |
| Katze Schrödinger | npc_katze | Katze | 8322 | 0 | — | 3× 2048×2048 | 5.8 | 491 | True |
| Kiosk-Zeus | npc_zeus | Zeitungskiosk | 8129 | 0 | — | 3× 2048×2048 | 7.3 | 579 | True |
| Klaus | npc_klaus | Türsteher-Roboter | 8388 | 0 | — | 3× 2048×2048 | 7.4 | 531 | True |
| Kurt | npc_kurt | Taube, Dachgarten | 8237 | 0 | — | 3× 2048×2048 | 7.0 | 540 | True |
| Käpt'n Kabel | npc_kabel | Brücke | 8318 | 28 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 7.1 | 826 | True |
| Madame Jackpot | npc_jackpot | Casino | 8136 | 52 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 7.4 | 1019 | True |
| Mortimer | npc_mortimer | Empfangsroboter | 8422 | 0 | — | 3× 2048×2048 | 7.5 | 539 | True |
| Prof. Staub | npc_staub | Archivar | 8361 | 0 | — | 3× 2048×2048 | 6.8 | 517 | True |
| Ramen-Kraken | npc_kraken | Serverkern | 8188 | 0 | — | 3× 2048×2048 | 7.9 | 606 | True |
| Ratten-Trupp | npc_ratten | Streikende Ratten | 8383 | 0 | — | 3× 2048×2048 | 7.9 | 545 | True |
| Rostige Rosi | npc_rosi | Schrotthändlerin, Schrottplatz | 8147 | 28 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 8.3 | 797 | True |
| Schaffner 4711 | npc_schaffner | Bahnhof | 8105 | 0 | — | 3× 2048×2048 | 6.1 | 511 | True |
| Schicht | npc_schicht | Streikführer mit Megafon, Hyperhub | 8428 | 0 | — | 3× 2048×2048 | 7.4 | 544 | True |
| Schnipp | npc_schnipp | Friseur | 8115 | 40 | idle (8.33 s), talk (5.9 s) | 3× 2048×2048 | 8.0 | 948 | True |
| Sebastian.exe | npc_sebastian | Butler, Promenade | 8141 | 0 | — | 3× 2048×2048 | 6.8 | 521 | True |
| Stempel-Stefan | npc_stefan | Beamter | 8432 | 0 | — | 3× 2048×2048 | 5.7 | 503 | True |
| Streikposten | npc_streikposten | Streikender Roboter | 8232 | 0 | — | 3× 2048×2048 | 7.3 | 540 | True |
| Tackert | npc_tackert | Hamster | 8260 | 0 | — | 3× 2048×2048 | 4.8 | 469 | True |
| Techniker Flimmer | npc_flimmer | Hologramm-Techniker | 8211 | 0 | — | 3× 2048×2048 | 6.2 | 531 | True |
| Wuschel (repariert) | npc_wuschel | rollender Putzroboter, Schrottplatz | 8379 | 0 | — | 3× 2048×2048 | 5.5 | 500 | True |
| Zen | npc_zen | Roboter im Bademantel | 8342 | 0 | — | 3× 2048×2048 | 7.5 | 533 | True |

### Statist (4)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Bürger (Mann) | buerger_mann | Passanten, Schlange, Menge | 15542 | 52 | idle (2.8 s), sad (2.67 s), cheer (2.87 s) | — | — | 1113 | True |
| Bürger (alt) | buerger_alt | Passanten, Schlange, Menge | 15826 | 28 | idle (5.33 s), sad (2.67 s), cheer (6.53 s) | — | — | 1196 | True |
| Bürgerin | buerger_frau | Passanten, Schlange, Menge | 15372 | 52 | idle (7.33 s), sad (4 s), cheer (1.87 s) | — | — | 1325 | True |
| Kompaktroboter | robot_kompakt | Roboter in Menge und Gasse | 15095 | 46 | idle (9.93 s), sad (9.33 s), walk (1 s) | — | — | 1498 | True |

### Fahrzeug (7)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Hoverboard | hoverboard | Pixels Brett | 15821 | 0 | — | — | — | 1051 | True |
| Monorail (gesamter Zug) | npc_monorail | Einschienenbahn „Neo-Loop“ | 12503 | 0 | — | 3× 2048×2048 | 6.4 | 755 | False |
| Monorail Cockpit | npc_cockpit | Einschienenbahn „Neo-Loop“ | 15458 | 0 | — | 3× 2048×2048 | 6.7 | 973 | True |
| Monorail Kopfwagen | npc_monorail_kopf | Einschienenbahn „Neo-Loop“ | 5983 | 0 | — | 3× 2048×2048 | 7.8 | 505 | True |
| Monorail Mittelwagen | npc_monorail_mitte | Einschienenbahn „Neo-Loop“ | 5872 | 0 | — | 3× 2048×2048 | 7.9 | 494 | True |
| Polizeidrohne | polizeidrohne | Patrouille | 15615 | 0 | — | — | — | 1098 | True |
| Spinner-Taxi | spinner_taxi | Fahrzeug der Stadt (Farbvarianten) | 15570 | 0 | — | — | — | 895 | True |

### Gebäude (12)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Niedriger Block | low_block | Häuser der Unterstadt | 4245 | 0 | — | — | — | 450 | True |
| Niedriges Marktgebäude | low_market | Häuser entlang der Nudelgasse | 4543 | 0 | — | — | — | 408 | True |
| Schwebende Kuppel | float_dome | Schwebende Häuser der Oberstadt | 5155 | 0 | — | — | — | 409 | True |
| Schwebende Pagode | float_pagoda | Schwebende Häuser der Oberstadt | 4961 | 0 | — | — | — | 509 | True |
| Schwebende Villa | float_villa | Schwebende Häuser der Oberstadt | 4045 | 0 | — | — | — | 455 | True |
| Schwebender Komplex | float_cluster | Schwebende Häuser der Oberstadt | 4721 | 0 | — | — | — | 469 | True |
| Turm „Hub“ | tower_hub | Wolkenkratzer | 4777 | 0 | — | — | — | 506 | True |
| Turm „Nadel“ | tower_needle | Wolkenkratzer | 4932 | 0 | — | — | — | 607 | True |
| Turm „Platte“ | tower_slab | Wolkenkratzer | 4511 | 0 | — | — | — | 469 | True |
| Turm „Rund“ | tower_round | Wolkenkratzer | 4367 | 0 | — | — | — | 345 | True |
| Turm „Ziggurat“ | tower_ziggurat | Wolkenkratzer | 4802 | 0 | — | — | — | 433 | True |
| Turm „Zwilling“ | tower_twin | Wolkenkratzer | 4433 | 0 | — | — | — | 582 | True |

### Objekt (1)

| Name | ID | Rolle / Ort | Dreiecke | Gelenke | Animationen | Textur | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|---|---|---|
| Suppenautomat | suppenautomat | Automat in Gasse und Imbiss | 15133 | 0 | — | — | — | 929 | True |

### Prop (55)

| Name | ID | Zustand | Dreiecke | GLB (MB) | JS (KB) | im Film |
|---|---|---|---|---|---|---|
| Aufzug Offen | npc_prop_aufzug_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 4724 | 6.0 | 389 | False |
| Aufzug Zu | npc_prop_aufzug_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5177 | 6.8 | 426 | False |
| Bohnenwolke | npc_prop_bohnenwolke | Zustandsvariante eines Bühnen-Objekts | 5182 | 7.8 | 432 | False |
| Brueckenpanel | npc_prop_brueckenpanel | Zustandsvariante eines Bühnen-Objekts | 5108 | 6.3 | 447 | False |
| Brunnen | npc_prop_brunnen | Zustandsvariante eines Bühnen-Objekts | 5216 | 7.2 | 416 | True |
| Drucker | npc_prop_drucker | Zustandsvariante eines Bühnen-Objekts | 5162 | 6.3 | 444 | False |
| Firewall Offen | npc_prop_firewall_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5142 | 6.2 | 432 | False |
| Firewall Zu | npc_prop_firewall_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5232 | 6.2 | 494 | True |
| Foto Rahmen | npc_prop_foto_rahmen | Zustandsvariante eines Bühnen-Objekts | 5150 | 6.5 | 398 | False |
| Gate Offen | npc_prop_gate_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5203 | 6.7 | 460 | False |
| Gate Zu | npc_prop_gate_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5080 | 4.7 | 368 | False |
| Gitter Offen | npc_prop_gitter_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 4238 | 5.8 | 358 | False |
| Gitter Zu | npc_prop_gitter_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5019 | 6.2 | 435 | False |
| Golfstaender | npc_prop_golfstaender | Zustandsvariante eines Bühnen-Objekts | 4759 | 7.6 | 416 | True |
| Holodrucker An | npc_prop_holodrucker_an | Zustandsvariante „an“ eines Bühnen-Objekts | 5100 | 8.2 | 435 | True |
| Holodrucker Aus | npc_prop_holodrucker_aus | Zustandsvariante „aus“ eines Bühnen-Objekts | 4778 | 5.9 | 376 | False |
| Kabel Gekappt | npc_prop_kabel_gekappt | Zustandsvariante „gekappt“ eines Bühnen-Objekts | 5102 | 7.4 | 411 | False |
| Kabel Verbunden | npc_prop_kabel_verbunden | Zustandsvariante „verbunden“ eines Bühnen-Objekts | 5029 | 6.8 | 409 | False |
| Kaffeepflanze | npc_prop_kaffeepflanze | Zustandsvariante eines Bühnen-Objekts | 5150 | 7.7 | 399 | True |
| Kanaldeckel Offen | npc_prop_kanaldeckel_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5196 | 6.2 | 374 | False |
| Kanaldeckel Zu | npc_prop_kanaldeckel_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5068 | 5.9 | 379 | False |
| Kanalgitter Zu | npc_prop_kanalgitter_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4667 | 7.0 | 401 | False |
| Keypad | npc_prop_keypad | Zustandsvariante eines Bühnen-Objekts | 4806 | 6.3 | 368 | False |
| Kiste Offen | npc_prop_kiste_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5006 | 6.6 | 450 | False |
| Kiste Zu | npc_prop_kiste_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4758 | 6.1 | 456 | True |
| Kranmagnet Haken | npc_prop_kranmagnet_haken | Zustandsvariante eines Bühnen-Objekts | 5171 | 6.7 | 394 | False |
| Lore Haken | npc_prop_lore_haken | Zustandsvariante eines Bühnen-Objekts | 5098 | 8.0 | 439 | False |
| Lore Schiene | npc_prop_lore_schiene | Zustandsvariante eines Bühnen-Objekts | 5054 | 7.0 | 432 | False |
| Rauchmelder | npc_prop_rauchmelder | Zustandsvariante eines Bühnen-Objekts | 5284 | 4.9 | 381 | False |
| Roulette | npc_prop_roulette | Zustandsvariante eines Bühnen-Objekts | 4348 | 7.0 | 391 | True |
| Schleuse Offen | npc_prop_schleuse_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5080 | 6.8 | 405 | False |
| Schleuse Zu | npc_prop_schleuse_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4707 | 6.5 | 382 | False |
| Schranke Offen | npc_prop_schranke_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5080 | 4.5 | 340 | False |
| Schranke Zu | npc_prop_schranke_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4971 | 6.2 | 432 | False |
| Sicherungskasten Offen Heiss | npc_prop_sicherungskasten_offen_heiss | Zustandsvariante „heiss“ eines Bühnen-Objekts | 4864 | 6.4 | 389 | False |
| Sicherungskasten Offen Leer | npc_prop_sicherungskasten_offen_leer | Zustandsvariante „leer“ eines Bühnen-Objekts | 5091 | 5.6 | 395 | False |
| Sicherungskasten Zu | npc_prop_sicherungskasten_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 5072 | 5.0 | 370 | True |
| Socke | npc_prop_socke | Zustandsvariante eines Bühnen-Objekts | 5253 | 4.7 | 352 | False |
| Steuerpult | npc_prop_steuerpult | Zustandsvariante eines Bühnen-Objekts | 4956 | 6.7 | 448 | True |
| Tastenfeld | npc_prop_tastenfeld | Zustandsvariante eines Bühnen-Objekts | 4000 | 5.8 | 354 | False |
| Teddy Sessel | npc_prop_teddy_sessel | Zustandsvariante eines Bühnen-Objekts | 5107 | 5.5 | 378 | False |
| Terminal An | npc_prop_terminal_an | Zustandsvariante „an“ eines Bühnen-Objekts | 4925 | 4.6 | 389 | True |
| Terminal Aus | npc_prop_terminal_aus | Zustandsvariante „aus“ eines Bühnen-Objekts | 4893 | 5.8 | 394 | False |
| Topf Gewachsen | npc_prop_topf_gewachsen | Zustandsvariante „gewachsen“ eines Bühnen-Objekts | 4804 | 7.6 | 451 | False |
| Topf Trocken | npc_prop_topf_trocken | Zustandsvariante „trocken“ eines Bühnen-Objekts | 5074 | 4.5 | 350 | True |
| Tresortuer | npc_prop_tresortuer | Zustandsvariante eines Bühnen-Objekts | 4995 | 6.7 | 424 | True |
| Tuer Kantine Offen | npc_prop_tuer_kantine_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 4816 | 6.4 | 410 | False |
| Tuer Kantine Zu | npc_prop_tuer_kantine_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4765 | 6.5 | 415 | False |
| Tuer Personal Offen | npc_prop_tuer_personal_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 4968 | 5.2 | 381 | False |
| Tuer Personal Zu | npc_prop_tuer_personal_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4810 | 5.6 | 335 | False |
| Turbine An | npc_prop_turbine_an | Zustandsvariante „an“ eines Bühnen-Objekts | 5159 | 7.9 | 449 | True |
| Turbine Aus | npc_prop_turbine_aus | Zustandsvariante „aus“ eines Bühnen-Objekts | 4949 | 6.8 | 395 | False |
| Vitrine Offen | npc_prop_vitrine_offen | Zustandsvariante „offen“ eines Bühnen-Objekts | 5074 | 5.1 | 407 | False |
| Vitrine Zu | npc_prop_vitrine_zu | Zustandsvariante „zu“ eines Bühnen-Objekts | 4710 | 4.3 | 402 | True |
| Wasserhahn | npc_prop_wasserhahn | Zustandsvariante eines Bühnen-Objekts | 5160 | 7.2 | 404 | False |

### Gegenstand (49)

| Name | ID | Dreiecke | Textur | GLB (MB) | JS (KB) |
|---|---|---|---|---|---|
| Akte „KLEO“ | npc_item_kleo_akte | 2551 | 3× 2048×2048 | 6.9 | 300 |
| Altes Foto | npc_item_altes_foto | 2619 | 3× 2048×2048 | 4.5 | 249 |
| Antiker Raumanzug | npc_item_raumanzug | 3091 | 3× 2048×2048 | 8.9 | 349 |
| Baguette | npc_item_baguette | 3161 | 3× 2048×2048 | 6.4 | 265 |
| Bergbau-Helm | npc_item_bergbau_helm | 3062 | 3× 2048×2048 | 7.0 | 293 |
| Büroklammer | npc_item_buero_klammer | 3146 | 3× 2048×2048 | 6.7 | 283 |
| Code-Zettel | npc_item_code_zettel | 2537 | 3× 2048×2048 | 5.6 | 253 |
| Essstäbchen | npc_item_essstaebchen | 3158 | 3× 2048×2048 | 6.3 | 331 |
| Flasche mit Wasser | npc_item_flasche_wasser | 3117 | 3× 2048×2048 | 5.9 | 291 |
| Formular 404-B | npc_item_formular_404b | 2656 | 3× 2048×2048 | 7.0 | 336 |
| Genehmigung | npc_item_genehmigung | 2645 | 3× 2048×2048 | 6.7 | 306 |
| Geröstete Bohnen | npc_item_geroestete_bohnen | 3154 | 3× 2048×2048 | 3.4 | 204 |
| Geschlossene Kiste | npc_item_schroedinger_kiste | 2804 | 3× 2048×2048 | 6.2 | 347 |
| Geschmacks-Kristall | npc_item_kristall | 3142 | 3× 2048×2048 | 7.3 | 390 |
| Geschmacks-Sensor | npc_item_geschmacks_sensor | 3121 | 3× 2048×2048 | 7.2 | 330 |
| Glas graue Paste | npc_item_graue_paste | 3060 | 3× 2048×2048 | 5.9 | 259 |
| Glasfaserkabel | npc_item_glasfaserkabel | 3121 | 3× 2048×2048 | 6.7 | 330 |
| Glühbirne | npc_item_gluehbirne | 3180 | 3× 2048×2048 | 4.5 | 259 |
| Goldener Golfball | npc_item_goldener_golfball | 3063 | 3× 2048×2048 | 5.9 | 273 |
| Gummibärchen | npc_item_gummibaerchen | 3154 | 3× 2048×2048 | 3.6 | 204 |
| Gültiges Ticket | npc_item_gueltiges_ticket | 2536 | 3× 2048×2048 | 6.8 | 371 |
| Hackerchip „ZN“ | npc_item_zhang_chip | 2859 | 3× 2048×2048 | 6.9 | 347 |
| Holo-Siegel | npc_item_holo_siegel | 2791 | 3× 2048×2048 | 7.0 | 311 |
| Jackpot-Chip | npc_item_jackpot_chip | 3091 | 3× 2048×2048 | 5.8 | 339 |
| Kabelsalat | npc_item_kabelsalat | 3165 | 3× 2048×2048 | 8.4 | 397 |
| Kaffeebohnen | npc_item_kaffeebohnen | 3154 | 3× 2048×2048 | 5.1 | 268 |
| Kaffeetasse | npc_item_kaffeetasse | 3160 | 3× 2048×2048 | 4.1 | 250 |
| Kamillenblüten | npc_item_kamille | 3156 | 3× 2048×2048 | 8.5 | 368 |
| Kantinentablett | npc_item_tablett | 3176 | 3× 2048×2048 | 6.0 | 332 |
| Knuspertoast | npc_item_knuspertoast | 3168 | 3× 2048×2048 | 6.1 | 315 |
| Kranmagnet | npc_item_kranmagnet | 3068 | 3× 2048×2048 | 6.7 | 289 |
| Kräuterbund | npc_item_kraeuterbund | 2986 | 3× 2048×2048 | 7.8 | 360 |
| Leere Flasche | npc_item_flasche | 3132 | 3× 2048×2048 | 4.2 | 248 |
| Mitarbeiterkittel | npc_item_kittel | 2982 | 3× 2048×2048 | 6.1 | 299 |
| Neonröhre | npc_item_neonroehre | 3205 | 3× 2048×2048 | 6.5 | 441 |
| Nudelsieb | npc_item_nudelsieb | 2883 | 3× 2048×2048 | 8.2 | 327 |
| Platin-Pass | npc_item_platin_pass | 3206 | 3× 2048×2048 | 6.1 | 316 |
| Powerbank | npc_item_powerbank | 2986 | 3× 2048×2048 | 6.3 | 316 |
| Schraube | npc_item_schraube | 3130 | 3× 2048×2048 | 6.3 | 296 |
| Shuttle-Ticket | npc_item_shuttle_ticket | 2555 | 3× 2048×2048 | 7.8 | 314 |
| Sicherung | npc_item_sicherung | 3099 | 3× 2048×2048 | 5.3 | 243 |
| Skalpell | npc_item_skalpell | 3160 | 3× 2048×2048 | 6.5 | 293 |
| Sojasoße | npc_item_sojasosse | 3156 | 3× 2048×2048 | 5.6 | 284 |
| Speicherstick | npc_item_speicherstick | 2719 | 3× 2048×2048 | 6.1 | 308 |
| Stempel „GÜLTIG“ | npc_item_stempel | 2882 | 3× 2048×2048 | 5.0 | 235 |
| Stick mit Log | npc_item_log_stick | 3042 | 3× 2048×2048 | 5.6 | 310 |
| Zahnrad | npc_item_zahnrad | 3142 | 3× 2048×2048 | 5.6 | 286 |
| Zeitung „Tageskrümel“ | npc_item_zeitung | 3136 | 3× 2048×2048 | 6.5 | 391 |
| Zerknittertes Ticket | npc_item_altes_ticket | 3158 | 3× 2048×2048 | 5.3 | 300 |
